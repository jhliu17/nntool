from ._slurm import SlurmFunction as _SlurmFunction


__all__ = ["_SlurmFunction"]
