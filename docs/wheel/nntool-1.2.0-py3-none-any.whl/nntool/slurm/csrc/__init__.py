import cythonpackage

cythonpackage.init(__name__)

from ._function import SlurmFunction as _SlurmFunction
