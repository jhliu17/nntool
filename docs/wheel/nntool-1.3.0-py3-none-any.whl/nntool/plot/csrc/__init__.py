import cythonpackage

cythonpackage.init(__name__)
