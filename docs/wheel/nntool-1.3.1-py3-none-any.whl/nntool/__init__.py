def test_import():
    print(f"nntool located at {__file__} is imported!")
