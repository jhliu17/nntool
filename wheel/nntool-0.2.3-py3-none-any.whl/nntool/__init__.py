import cythonpackage

cythonpackage.init(__name__)


def test_import():
    print("mdtool is imported!")
