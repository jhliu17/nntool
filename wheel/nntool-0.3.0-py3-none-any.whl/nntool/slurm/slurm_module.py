import os
import sys
from functools import wraps
from warnings import warn
from typing import Any, Callable, Type, Union

import submitit

from ..parser import parse_from_cli
from .args import SlurmArgs
from .task import PyTorchDistributedTask


def get_slurm_executor(
    slurm_config: SlurmArgs,
    slurm_parameters_kwargs: dict = {},
    slurm_submission_kwargs: dict = {},
):
    executor = submitit.AutoExecutor(
        folder=slurm_config.slurm_output_folder,
        cluster=None if slurm_config.mode == "slurm" else slurm_config.mode,
    )

    # set additional parameters
    slurm_additional_parameters = {}
    if slurm_config.node_list:
        slurm_additional_parameters["nodelist"] = slurm_config.node_list
    if slurm_config.node_list_exclude:
        slurm_additional_parameters["exclude"] = slurm_config.node_list_exclude
    if slurm_config.mem:
        slurm_additional_parameters["mem"] = slurm_config.mem
    slurm_additional_parameters.update(slurm_parameters_kwargs)

    # set slurm parameters
    executor.update_parameters(
        name=slurm_config.slurm_job_name,
        slurm_partition=slurm_config.slurm_partition,
        nodes=slurm_config.num_of_node,
        slurm_tasks_per_node=slurm_config.tasks_per_node,
        slurm_cpus_per_task=slurm_config.cpus_per_task,
        slurm_gpus_per_node=(
            slurm_config.gpus_per_task * slurm_config.tasks_per_node
            if slurm_config.gpus_per_node is None
            else slurm_config.gpus_per_node
        ),  # gpu cannot be assigned in the task level
        timeout_min=slurm_config.timeout_min,
        slurm_additional_parameters=slurm_additional_parameters,
        **slurm_submission_kwargs,
    )

    return executor


def slurm_has_been_set_up() -> bool:
    """NNTOOL_SLURM_HAS_BEEN_SET_UP is a special environment variable to indicate that the slurm has been set up.

    :return: bool
    """
    # check whether slurm has been set up
    has_been_set_up = False
    if os.environ.get("NNTOOL_SLURM_HAS_BEEN_SET_UP") is not None:
        has_been_set_up = True
    return has_been_set_up


def _slurm_decorator(
    slurm_config: SlurmArgs,
    slurm_params_kwargs: dict = {},
    slurm_submit_kwargs: dict = {},
    *default_submit_fn_args,
    **default_submit_fn_kwargs,
):
    def decorator(submit_fn):
        @wraps(submit_fn)
        def wrapper(
            *submit_fn_args,
            **submit_fn_kwargs,
        ):
            submit_fn_args = (
                default_submit_fn_args if not submit_fn_args else submit_fn_args
            )
            submit_fn_kwargs = (
                default_submit_fn_kwargs if not submit_fn_kwargs else submit_fn_kwargs
            )

            executor = get_slurm_executor(
                slurm_config,
                slurm_parameters_kwargs=slurm_params_kwargs,
                slurm_submission_kwargs=slurm_submit_kwargs,
            )
            job = executor.submit(submit_fn, *submit_fn_args, **submit_fn_kwargs)

            # get result to run program in debug mode
            if slurm_config.mode != "slurm":
                job.result()

            return job

        return wrapper

    return decorator


def _slurm_dist_decorator(
    slurm_config: SlurmArgs,
    slurm_params_kwargs: dict = {},
    slurm_submit_kwargs: dict = {},
    slurm_task_kwargs: dict = {},
    system_argv: Union[list[str], None] = None,
    *default_submit_fn_args,
    **default_submit_fn_kwargs,
):
    def decorator(submit_fn):
        @wraps(submit_fn)
        def wrapper(
            *submit_fn_args,
            **submit_fn_kwargs,
        ):
            submit_fn_args = (
                default_submit_fn_args if not submit_fn_args else submit_fn_args
            )
            submit_fn_kwargs = (
                default_submit_fn_kwargs if not submit_fn_kwargs else submit_fn_kwargs
            )

            if not slurm_has_been_set_up():
                executor = get_slurm_executor(
                    slurm_config,
                    slurm_parameters_kwargs=slurm_params_kwargs,
                    slurm_submission_kwargs=slurm_submit_kwargs,
                )

                # prepare distributed env for the second launch
                task = PyTorchDistributedTask(
                    f"export NNTOOL_SLURM_HAS_BEEN_SET_UP=1; {slurm_config.distributed_launch_command}",
                    system_argv if system_argv is not None else list(sys.argv[1:]),
                    slurm_config,
                    verbose=True,
                    **slurm_task_kwargs,
                )

                job = executor.submit(task)

                # get result to run program in debug mode
                if slurm_config.mode != "slurm":
                    job.result()

                return job
            else:
                return submit_fn(*submit_fn_args, **submit_fn_kwargs)

        return wrapper

    return decorator


def slurm_launcher(
    ArgsType: Type[Any],
    parser: Union[str, Callable] = "tyro",
    slurm_key: str = "slurm",
    slurm_params_kwargs: dict = {},
    slurm_submit_kwargs: dict = {},
    slurm_task_kwargs: dict = {},
    *extra_args,
    **extra_kwargs,
):
    """A slurm launcher decorator for distributed or non-distributed job (controlled by `use_distributed_env` in slurm field). This decorator should be used as the program entry. The decorated function is non-blocking in the mode of `slurm`, while other modes cause blocking.

    **Exported Distributed Enviroment Variables**
    1. NNTOOL_SLURM_HAS_BEEN_SET_UP is a special environment variable to indicate that the slurm has been set up.
    2. After the set up, the distributed job will be launched and the following variables are exported:         num_processes: int, num_machines: int, machine_rank: int, main_process_ip: str, main_process_port: int.

    :param ArgsType: the experiment arguments type, which should be a dataclass (it
                     mush have a slurm field defined by `slurm_key`)
    :param slurm_key: the key of the slurm field in the ArgsType, defaults to "slurm"
    :param parser: the parser for the arguments, defaults to "tyro"
    :param slurm_config: SlurmArgs, the slurm configuration dataclass
    :param slurm_params_kwargs: extra slurm arguments for the slurm configuration, defaults to {}
    :param slurm_submit_kwargs: extra slurm arguments for `srun` or `sbatch`, defaults to {}
    :param slurm_task_kwargs: extra arguments for the setting of distributed task, defaults to {}
    :param extra_args: extra arguments for the parser
    :param extra_kwargs: extra keyword arguments for the parser
    :return: decorator function with main entry
    """
    argv = list(sys.argv[1:])
    args = parse_from_cli(ArgsType, parser, *extra_args, **extra_kwargs)

    # check if args have slurm field
    if not hasattr(args, slurm_key):
        raise ValueError(
            f"ArgsType should have a field named `{slurm_key}` to use `slurm_launcher` decorator."
        )
    slurm_config: SlurmArgs = getattr(args, slurm_key)

    # select the decorator
    decorator = (
        _slurm_decorator(slurm_config, slurm_params_kwargs, slurm_submit_kwargs, args)
        if not slurm_config.use_distributed_env
        else _slurm_dist_decorator(
            slurm_config,
            slurm_params_kwargs,
            slurm_submit_kwargs,
            slurm_task_kwargs,
            argv,
            args,
        )
    )

    return decorator


def slurm_distributed_launcher(
    ArgsType: Type[Any],
    parser: Union[str, Callable] = "tyro",
    slurm_key: str = "slurm",
    slurm_params_kwargs: dict = {},
    slurm_submit_kwargs: dict = {},
    slurm_task_kwargs: dict = {},
    *extra_args,
    **extra_kwargs,
):
    """A slurm launcher decorator for the distributed job. This decorator should be used for the distributed job only and as the program entry. The decorated function is non-blocking in the mode of `slurm`, while other modes cause blocking.

    **Exported Distributed Enviroment Variables**
    1. NNTOOL_SLURM_HAS_BEEN_SET_UP is a special environment variable to indicate that the slurm has been set up.
    2. After the set up, the distributed job will be launched and the following variables are exported:         num_processes: int, num_machines: int, machine_rank: int, main_process_ip: str, main_process_port: int.

    :param ArgsType: the experiment arguments type, which should be a dataclass (it
                     mush have a slurm field defined by `slurm_key`)
    :param slurm_key: the key of the slurm field in the ArgsType, defaults to "slurm"
    :param parser: the parser for the arguments, defaults to "tyro"
    :param slurm_config: SlurmArgs, the slurm configuration dataclass
    :param slurm_params_kwargs: extra slurm arguments for the slurm configuration, defaults to {}
    :param slurm_submit_kwargs: extra slurm arguments for `srun` or `sbatch`, defaults to {}
    :param slurm_task_kwargs: extra arguments for the setting of distributed task, defaults to {}
    :param extra_args: extra arguments for the parser
    :param extra_kwargs: extra keyword arguments for the parser
    :return: decorator function with main entry
    """
    warn(
        "`slurm_distributed_launcher` has been deprecated. Please use `slurm_launcher` instead, which supports both distributed or non-distributed job (controlled by `use_distributed_env` in slurm field).",
        DeprecationWarning,
        stacklevel=2,
    )
    argv = list(sys.argv[1:])
    args = parse_from_cli(ArgsType, parser, *extra_args, **extra_kwargs)

    # check if args have slurm field
    if not hasattr(args, slurm_key):
        raise ValueError(
            f"ArgsType should have a field named `{slurm_key}` to use `slurm_launcher` decorator."
        )
    slurm_config: SlurmArgs = getattr(args, slurm_key)

    decorator = _slurm_dist_decorator(
        slurm_config,
        slurm_params_kwargs,
        slurm_submit_kwargs,
        slurm_task_kwargs,
        argv,
        args,
    )

    return decorator


def slurm_function(
    submit_fn: Callable,
):
    """A decorator to annoate a function to be run in slurm. The function decorated by this decorator should be launched in the way below.
    ```
    @slurm_function
    def run_in_slurm(*args, **kwargs):
        pass

    job = run_in_slurm(slurm_config)(*args, **kwargs)
    ```
    The decorated function `submit_fn` is non-blocking now. To block and get the return value, you can call `job.result()`.
    """

    def wrapper(
        slurm_config: SlurmArgs,
        slurm_params_kwargs: dict = {},
        slurm_submit_kwargs: dict = {},
        slurm_task_kwargs: dict = {},
        system_argv: Union[list[str], None] = None,
    ):
        """A decorated function for the slurm job, which can be used for distributed or non-distributed job (controlled by `use_distributed_env` in the slurm dataclass).

        **Exported Distributed Enviroment Variables**
        1. NNTOOL_SLURM_HAS_BEEN_SET_UP is a special environment variable to indicate that the slurm has been set up.
        2. After the set up, the distributed job will be launched and the following variables are exported:         num_processes: int, num_machines: int, machine_rank: int, main_process_ip: str, main_process_port: int.

        :param slurm_config: SlurmArgs, the slurm configuration dataclass
        :param slurm_params_kwargs: extra slurm arguments for the slurm configuration, defaults to {}
        :param slurm_submit_kwargs: extra slurm arguments for `srun` or `sbatch`, defaults to {}
        :param slurm_task_kwargs: extra arguments for the setting of distributed task, defaults to {}
        :param system_argv: the system arguments for the second launch in the distributed task (by default it will use the current system arguments `sys.argv[1:]`), defaults to None
        :return: the wrapped submit function with configured slurm paramters
        """

        @wraps(submit_fn)
        def wrapped_submit_fn(
            *submit_fn_args,
            **submit_fn_kwargs,
        ):
            if not slurm_config.use_distributed_env:
                return _slurm_decorator(
                    slurm_config, slurm_params_kwargs, slurm_submit_kwargs
                )(submit_fn)(
                    *submit_fn_args,
                    **submit_fn_kwargs,
                )
            else:
                return _slurm_dist_decorator(
                    slurm_config,
                    slurm_params_kwargs,
                    slurm_submit_kwargs,
                    slurm_task_kwargs,
                    system_argv,
                )(submit_fn)(
                    *submit_fn_args,
                    **submit_fn_kwargs,
                )

        return wrapped_submit_fn

    return wrapper
