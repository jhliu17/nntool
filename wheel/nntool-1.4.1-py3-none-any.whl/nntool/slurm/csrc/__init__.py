from ._slurm import SlurmFunction as _SlurmFunction
