def test_import():
    print("mdtool is imported!")
